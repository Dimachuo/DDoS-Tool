apt install python python-pip termux-api clang  fftw libzmq freetype libpng pkg-config -y
LDFLAGS=" -lm -lcompiler\_rt" && pip install jupyter && clear
echo 'activate Python IDE(Interpreter) code :  print("codingwithmeet")'
echo "Start Local Server >> jupyter notebook"
